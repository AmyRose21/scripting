#if defined _pure_play_as_si_charger_included
 #endinput
#endif
#define _pure_play_as_si_charger_included

ConVar chargerHp;
ConVar chargerClawDmg;
ConVar chargerAbilityCooldown;
ConVar chargerImpactDmg;
ConVar chargerImpactRadius;
ConVar chargerHealPoint;

bool isChargerTouchHooked[MAXPLAYERS + 1];

void AddChargerConVars()
{
    char desc[64];
    Format(desc, 64, "%t", "ConVar Charger HP");
    chargerHp = CreateConVar("l4d2_play_as_si_charger_hp", "400", desc, 0, true, 100.0);
    Format(desc, 64, "%t", "ConVar Charger Claw Damage");
    chargerClawDmg = CreateConVar("l4d2_play_as_si_charger_claw_dmg", "100", desc, 0, true, 10.0);
    Format(desc, 64, "%t", "ConVar Charger Ability Cooldown");
    chargerAbilityCooldown = CreateConVar("l4d2_play_as_si_charger_ability_cooldown", "3.0", desc, 0, true, 1.0);
    Format(desc, 64, "%t", "ConVar Charger Impact Damage");
    chargerImpactDmg = CreateConVar("l4d2_play_as_si_charger_impact_dmg", "500.0", desc, 0, true, 100.0);
    Format(desc, 64, "%t", "ConVar Charger Impact Radius");
    chargerImpactRadius = CreateConVar("l4d2_play_as_si_charger_impact_radius", "500.0", desc, 0, true, 50.0);
    Format(desc, 64, "%t", "ConVar Charger Heal");
    chargerHealPoint = CreateConVar("l4d2_play_as_si_charger_heal_point", "200.0", desc, 0, true, 100.0);

    // HookEvent("charger_charge_start", OnChargerChargeStart);
    HookEvent("charger_charge_end", OnChargerChargeEnd);
}

public void OnChargerSuccess(int client)
{
    SetEntProp(client, Prop_Data, "m_iHealth", GetConVarInt(chargerHp));
    SetEntProp(client, Prop_Data, "m_iMaxHealth", GetConVarInt(chargerHp));
}

// When start charging, this event called more than once, don't use it

// public void OnChargerChargeStart(Handle event, const char[] name, bool dontBroadcast)
// {
//     int userid = GetClientOfUserId(GetEventInt(event, "userid"));
//     if(!IsSurvivor(client) || !(playerStatus[client] & (1 << PLAYABLE_CHARGER)))
//         return;
//     isCharging[userid] = true;
// }

public void OnChargerChargeEnd(Event event, const char[] name, bool dontBroadcast)
{
    int client = GetClientOfUserId(GetEventInt(event, "userid"));
    if(!IsSurvivor(client) || !(playerStatus[client] == PLAYABLE_CHARGER))
        return;
    UnhookTouchCharger(client);
    SetAbilityCooldown(client, GetConVarFloat(chargerAbilityCooldown));
}

public void OnChargerAbilityUse(int client)
{
    HookTouchCharger(client);
}

public void OnPlayerChargerDeath(int client)
{
    UnhookTouchCharger(client);
}

void HookTouchCharger(int client)
{
    if(!isChargerTouchHooked[client])
    {
        isChargerTouchHooked[client] = true;
        SDKHook(client, SDKHook_StartTouch, OnStartTouchCharger);
    }
}

void UnhookTouchCharger(int client)
{
    SDKUnhook(client, SDKHook_StartTouch, OnStartTouchCharger);
    isChargerTouchHooked[client] = false;
}

Action OnStartTouchCharger(int entity, int other)
{
    if(IsSpecialInfected(other))
    {
        EmitSoundToClient(entity, "player/charger/loud_chargerimpact_03.wav");
        SDKHooks_TakeDamage(other, entity, entity, GetConVarFloat(chargerImpactDmg));
    }
    else
    {
        char classname[9];
        GetEntityClassname(other, classname, 9);

        if(classname[0] != 'i' && classname[0] != 'w') return Plugin_Continue;  //For Performance

        if(StrEqual(classname, "infected", false) || StrEqual(classname, "witch", false))
        {
            EmitSoundToClient(entity, "player/charger/loud_chargerimpact_03.wav");
            SDKHooks_TakeDamage(other, entity, entity, GetConVarFloat(chargerImpactDmg));
        }
    }
    return Plugin_Continue;
}

public void L4D2_OnChargerImpact(int client)
{
    if(!IsSurvivor(client) || !(playerStatus[client] == PLAYABLE_CHARGER))
        return;

    UnhookTouchCharger(client);
    float center[3];
    float target[3];
    GetAbsOrigin(client, center);
    for(int i = 1; i <= MaxClients; i++)
    {
        if(!IsInfected(i) || !IsPlayerAlive(i))
            continue;

        GetAbsOrigin(i, target);
        if(GetVectorDistance(center, target) <= GetConVarFloat(chargerImpactRadius))
        {
            SDKHooks_TakeDamage(i, client, client, 1.0, DMG_BLAST, -1, NULL_VECTOR, NULL_VECTOR, false);
        }
    }

    for(int i = MAXPLAYERS + 1; i < GetMaxEntities(); i++)
    {
        if(!IsValidEntity(i)) continue;

        char classname[9];
        GetEntityClassname(i, classname, 9);
        
        if(classname[0] != 'i' && classname[0] != 'w') continue;  //For Performance

        if(StrEqual(classname, "infected", false) || StrEqual(classname, "witch", false))
        {
            GetAbsOrigin(i, target);
            if(GetVectorDistance(center, target)  <= GetConVarFloat(chargerImpactRadius))
            {
                SDKHooks_TakeDamage(i, client, client, 1.0, DMG_BLAST, -1, NULL_VECTOR, NULL_VECTOR, false);
            }
        }
    }
}